
<html>
    <head>
     <meta http-equiv="refresh" content="6;url=https://globeexservices.com/sms/index2.php" /> 
          
    </head>
    <style>
        
       body { background-color: #ffffff; } 
       div {
    position:relative;
    height: 100%;
    width:100%;
}

div img {
    position:absolute;
    top:0;
    left:0;
    right:0;
    bottom:0;
    margin:auto;
}
    </style>
    
    <body>
        
        <div><img src="https://cdn-images-1.medium.com/max/1600/1*CsJ05WEGfunYMLGfsT2sXA.gif"></div>
        
    </body>
</html>
