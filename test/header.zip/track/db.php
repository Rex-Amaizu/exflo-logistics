<?php    
    
    $servername = "localhost";
$username = "doortod1_001";
$password = "An0therrichard3303";
$dbname = "doortod1_001";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

