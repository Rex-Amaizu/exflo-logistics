<?php    
    
$servername = "localhost";
$username = "firsyytq_birdie";
$password = "stubborn28312020";
$dbname = "firsyytq_bird";
$date = date('d-m-Y H:m:s');
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
